@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "EDGE="
if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
if not defined EDGE if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined EDGE if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if not defined EDGE (
  echo Microsoft Edge was not found.
  echo Please install Microsoft Edge and run this file again.
  pause
  exit /b 1
)

if not exist "%~dp0Profile" mkdir "%~dp0Profile"

start "" "%EDGE%" ^
  --app="file:///%~dp0FoZoWoBlog.html" ^
  --user-data-dir="%~dp0Profile" ^
  --no-first-run ^
  --no-default-browser-check ^
  --disable-features=msEdgeSidebarV2

exit /b 0
