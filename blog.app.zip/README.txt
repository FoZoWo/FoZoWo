FoZoWo Blog App v1.0

This version is a dedicated blog application.

Changes:
- Removed the FoZoWo Browser top navigation/address bar.
- Starts directly at:
  https://www.fozowo.f5.si/blog
- Uses Microsoft Edge app mode so there is no normal browser toolbar.
- Opens in a separate FoZoWo Blog App window.
- The uploaded source HTML is included as FoZoWoBlog.html.

Start:
Double-click START_FoZoWo_Blog_App.bat

Requirement:
Microsoft Edge must be installed.

The browser engine is Chromium-based through installed Microsoft Edge.
The app mode window does not show an address bar or browser navigation toolbar.
