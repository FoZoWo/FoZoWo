FoZoWo Blog Independent App v1.0

Based on the uploaded blog (20)(1).html.

Changes for standalone app:
- Removed the external shared header.html dependency.
- Removed the browser address bar/navigation UI entirely.
- Kept the blog page layout, theme system, search, archive, pagination, article view and notification logic from the source.
- Starts in Microsoft Edge Chromium App Mode, so the blog opens in a dedicated app-style window.
- Home content remains the FoZoWo blog and the page's API endpoint is unchanged.

Start:
Double-click START_FoZoWo_BlogApp.bat

Requirement:
Microsoft Edge must be installed.

Note:
This app uses the uploaded HTML as its core page. The blog still fetches live post data from the API URL contained in the original HTML, so internet access is required for the live article list.
